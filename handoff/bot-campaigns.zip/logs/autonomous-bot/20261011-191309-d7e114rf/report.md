# 自主对 bot 实战记录

官方 Codex CLI + ChatGPT 订阅；请求模型固定 `gpt-6-luna`；真实 Linux SC2 标准开局。
用户已追加授权直到困难胜利；逐局追加预算，历史计数不清零。 每局最多24次战斗请求、600游戏秒和660墙钟秒。

| 局 | 难度 | 结果 | 终止原因 | 战斗答复/尝试 | 游戏秒 | 复盘 | 回放 |
|---|---|---|---|---|---|---|---|
| 1 | easy | Defeat | request_budget | 24/24 | 302.4 | [strategy](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-01-easy/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-01-easy/match.SC2Replay) |
| 2 | easy | Unknown | model_unavailable | 18/18 | 450.3 | [strategy](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-02-easy/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-02-easy/match.SC2Replay) |
| 3 | easy | Defeat | request_budget | 24/24 | 579.4 | [feature_gap](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-03-easy/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-03-easy/match.SC2Replay) |
| 4 | easy | Defeat | request_budget | 24/24 | 580.5 | [strategy](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-04-easy/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-04-easy/match.SC2Replay) |
| 5 | easy | Defeat | request_budget | 24/24 | 578.4 | [strategy](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-05-easy/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-05-easy/match.SC2Replay) |
| 6 | easy | Defeat | request_budget | 24/24 | 578.3 | [strategy](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-06-easy/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-06-easy/match.SC2Replay) |
| 7 | easy | Defeat | request_budget | 24/24 | 580.7 | [strategy](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-07-easy/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-07-easy/match.SC2Replay) |
| 8 | easy | Defeat | request_budget | 24/24 | 582.2 | [strategy](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-08-easy/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-08-easy/match.SC2Replay) |
| 9 | easy | Unknown | context_budget | 23/23 | 575.3 | [strategy](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-09-easy/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-09-easy/match.SC2Replay) |
| 10 | easy | Victory | engine_end | 17/17 | 421.4 | [win](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-10-easy/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-10-easy/match.SC2Replay) |
| 11 | hard | Unknown | context_budget | 13/13 | 325.2 | [strategy](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-11-hard/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-11-hard/match.SC2Replay) |
| 12 | hard | Victory | engine_end | 21/22 | 532.2 | [win](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-12-hard/review.json) | [SC2Replay](/workspace/sc2Llm/logs/autonomous-bot/20261011-191309-d7e114rf/match-12-hard/match.SC2Replay) |

真实引擎确认胜利才升级到困难；预算止损/投降不会算作胜利，未知结果保持未知。
结束原因：`goal_reached`；困难胜利目标完成：`True`。
总预算计数：278/312；角色分布：`{'battle': 261, 'review': 15, 'repair': 2}`。
战斗答复 260 次、尝试 261 次。战斗输入 token 6690042（缓存 2311168），输出 58333；不含复盘与修复 token。

每局完整报告、错误日志、原始模型回答、复盘和回放均在对应 match-* 目录。
第三局复盘确认部分减员会错误中止全队，模型在隔离副本修复 `arena/spatial.py`。新回归旧代码 2 项中失败 1 项，修复后 2 项通过；当时 86 项已有检查通过。
第五局后独立机械复现证明：可见射程内目标掉血时，原地攻击仍会被移动看门狗误判。模型修复后，新回归旧代码 2 项中失败 1 项、修复后 2 项通过，114 项已有检查通过。此复现不证明第五局具体错误的战斗归因。
有效交战只按当前可见、可攻击、射程内目标生命值下降认定；无交战停滞与任务期限继续生效。
第六局新增错误观测指向大型基地建筑。离线复现确认射程遗漏双方半径；操作员补齐几何判断，3 项新回归旧代码失败 2 项、修复后全部通过。第八局开始加载此修正；第七局已在运行，使用前一版本。
八局结束后修正请求上限调度：不再立即打断最后一份答复下达的命令，达到调用上限后停止模型调用，已下达命令仅执行至原有时间上限。离线 2 项新回归旧代码均失败、修复后通过；当时仅有离线验证；后续实战结果以表格和真实引擎终局为准。
新增修复回归继续纳入以后每次修复的验证门禁。
第一局修复了情报刷新导致过密请求；第二局后压缩重复历史并保留当前观测；第三局后复盘时间线使用任务变化编码，全部世界采样保留。
第二局的 Unknown 来自本地输入长度检查超限；原报告的 model_unavailable 标签不是订阅额度耗尽的证据。该本地问题已修正。
一次本地复盘长度检查失败也保守计入总预算，但未发出模型请求。

最新相关整合验证：136 项，结果 `通过`。

复盘补全了交战记录：阵亡和离开视野分别统计；不把敌军损失、清空主矿或任务到达当作胜利。
第五局官方复盘误称没有我方损失；原始汇总记录 12 名我方陆战队阵亡。该错误保留在 review.json，操作员诊断已明确纠正。
第八局复盘误称投降被阻止；实际是宿主按调用预算离开，leave 已确认。37 名兵是较早采样，最终世界为 38 名。真实终局和来源以 match.json 为准。
本轮调用预算和实战局数从未重置；当前额度快照不能证明此前是否刚重置过。


第9局：游戏575.3秒触发本地战斗上下文上限，Unknown，23次战斗答复，回放与清理已完成。原始被拒载荷已保存；压缩重复静态建议和历史说明后，当前世界、任务、错误、联系人和地图观测保持一致。
第9局独立复盘脚本曾错误选择其他登录上下文而返回401。官方新授权成功；修复登录目录选择后真实复盘完成。此前把这个401直接归因为用户授权过期不准确。默认客户端现在始终选择仓库独立ChatGPT登录，避免继承平台登录；失败的两次复盘尝试仍计入预算。
第10局开始实际启用官方结构化输出与同一gpt-6-luna的high推理设置，首队20人集结；首批模型答复已证实采用这两个设置。战术修订基于第9局33名陆战队阵亡，原模型复盘及原战术均保留。实际胜负以对应match.json为准。

官方 Codex Plus 5小时额度剩余 76%，下次重置北京时间 2026-10-12 02:54:02。此为本轮结束后的历史快照。
官方 Codex Plus 周额度剩余 81%，下次重置北京时间 2026-10-18 16:47:45。此为本轮结束后的历史快照。

第 1 局：观察到敌方阵亡 `{'Marine': 3}`；我方阵亡 `{'Marine': 12}`。仅己方原始可见记录，不推断击杀归属。
第 2 局：观察到敌方阵亡 `{'Marine': 3, 'Marauder': 2, 'SCV': 2, 'KD8Charge': 2, 'Reaper': 1}`；我方阵亡 `{'Marine': 26}`。仅己方原始可见记录，不推断击杀归属。
第 3 局：观察到敌方阵亡 `{'Marine': 12, 'SCV': 32, 'Marauder': 4, 'Reaper': 1, 'Hellion': 1}`；我方阵亡 `{'Marine': 39}`。仅己方原始可见记录，不推断击杀归属。
第 4 局：观察到敌方阵亡 `{'Marine': 11, 'Marauder': 2, 'SCV': 35, 'Reaper': 2, 'KD8Charge': 2, 'SupplyDepotLowered': 3, 'Factory': 1, 'BarracksTechLab': 2, 'Hellion': 4, 'Raven': 1}`；我方阵亡 `{'Marine': 7}`。仅己方原始可见记录，不推断击杀归属。
第 5 局：观察到敌方阵亡 `{'Marine': 9, 'Marauder': 4, 'SCV': 37, 'SupplyDepotLowered': 4, 'MULE': 1, 'Barracks': 2, 'TechLab': 1, 'Hellion': 3, 'OrbitalCommand': 1, 'Refinery': 2, 'Factory': 1}`；我方阵亡 `{'Marine': 12}`。仅己方原始可见记录，不推断击杀归属。
第 6 局：观察到敌方阵亡 `{'Marine': 9, 'Marauder': 3, 'SCV': 43, 'SupplyDepot': 1, 'Hellion': 4, 'MULE': 1, 'SupplyDepotLowered': 1, 'BarracksTechLab': 1, 'Starport': 1, 'Factory': 1, 'CommandCenter': 1}`；我方阵亡 `{'Marine': 13}`。仅己方原始可见记录，不推断击杀归属。
第 7 局：观察到敌方阵亡 `{'Marine': 7, 'Marauder': 4, 'SCV': 42, 'Hellion': 3, 'Barracks': 2, 'TechLab': 1, 'StarportTechLab': 1, 'Starport': 1, 'OrbitalCommand': 1, 'CommandCenter': 1, 'SupplyDepotLowered': 2, 'Refinery': 2, 'Factory': 1}`；我方阵亡 `{'Marine': 14}`。仅己方原始可见记录，不推断击杀归属。
第 8 局：观察到敌方阵亡 `{'Marine': 8, 'Marauder': 4, 'SCV': 34, 'Reaper': 1, 'KD8Charge': 1, 'SupplyDepotLowered': 5, 'Factory': 2, 'Hellion': 1, 'BarracksTechLab': 1, 'MULE': 1, 'Barracks': 1, 'OrbitalCommand': 1, 'Refinery': 2, 'Raven': 1, 'StarportTechLab': 1, 'Starport': 1}`；我方阵亡 `{'Marine': 7}`。仅己方原始可见记录，不推断击杀归属。
第 9 局：观察到敌方阵亡 `{'Marine': 13, 'SCV': 20, 'Marauder': 4, 'CommandCenter': 2, 'Hellion': 2}`；我方阵亡 `{'Marine': 33}`。仅己方原始可见记录，不推断击杀归属。
第 10 局：观察到敌方阵亡 `{'Marine': 5, 'Marauder': 3, 'SCV': 24, 'SupplyDepotLowered': 4, 'Barracks': 1, 'MULE': 2, 'TechLab': 1, 'OrbitalCommand': 1, 'Refinery': 2}`；我方阵亡 `{'SCV': 1, 'Marine': 6}`。仅己方原始可见记录，不推断击杀归属。
第 11 局：观察到敌方阵亡 `{'Hellion': 1}`；我方阵亡 `{'SCV': 1, 'Marine': 20}`。仅己方原始可见记录，不推断击杀归属。
第 12 局：观察到敌方阵亡 `{'Marine': 14, 'Marauder': 10, 'SCV': 32, 'CommandCenter': 1, 'FactoryTechLab': 4, 'Factory': 2, 'SupplyDepotLowered': 7, 'BarracksTechLab': 5, 'WidowMine': 1, 'MULE': 1, 'Barracks': 2, 'Hellion': 2, 'EngineeringBay': 1, 'MissileTurret': 2, 'Starport': 1, 'TechLab': 1, 'OrbitalCommand': 1, 'Refinery': 2}`；我方阵亡 `{'SCV': 1, 'Marine': 10}`。仅己方原始可见记录，不推断击杀归属。
## 目标已完成（2026-10-12）

第10局easy：真实引擎Victory，421.4游戏秒、17次请求完成。第12局hard：真实引擎Victory，532.2游戏秒、542.44墙钟秒；22次请求尝试、21次完成，终局时取消1份待答复请求。两局引擎动作错误均为0，回放分别14884与18741字节。12局真实回放均存在，全部清理完成。

第11局hard先以20名无升级陆战队进攻，记录20名陆战队阵亡；本地密集警报长度检查终止，Unknown，不伪造败局。已用原始被拒载荷验证无损接触表编码，警报中的tags/坐标/时间/可见性和所有当前世界、任务、错误记录保持事实一致；原始日志与修正诊断保留。第12局采用16陆战队加8掠夺者的24人首队、提前气矿/科技实验室，并确认兴奋剂、战斗盾牌、震撼弹后持续整队进攻和补员，取得硬难度胜利。

战后真实复盘完成；程序自动停止，没有第13局。总预留调用计数278/312：战斗261、复盘15、修复2。12份复盘完成；复盘计数还保留1次本地长度检查失败、2次错误登录上下文的401失败。中断与重新授权都没有重置历史预算。

完成后官方只读Codex Plus额度快照：5小时窗口剩余74%，周额度剩余74%。此为记录时的历史快照。

获胜对局实际使用的完整提示词、模型设置、种子和源码哈希已保存于 winning-strategy.json；与获胜后的复盘建议区分，后者没有另开实战验证。
