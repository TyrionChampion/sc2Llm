# 扩张运营自主实战记录

当前账本模型：`chatgpt/gpt-6-luna`；每局最多24次战斗请求、30分钟；明显败势止损。
下局待切换：`opencode-go/deepseek-v4.1-flash`；环境状态见campaign.json。
模型决定战略、生产、扩张和部署；脚本执行明确命令、采矿与已分配军队微操。

当前状态：finished；本轮困难胜利：False。
本轮请求尝试：451/572；保留此前278次，累计729次。

|局次|模型|结果来源|结果|结束原因|完成请求|
|---|---|---|---|---|---|
|1|chatgpt/gpt-6-luna|unverified|Unknown|environment_error|10|
|1-retry|chatgpt/gpt-6-luna|engine_player_result|Defeat|engine_end|12|
|2|chatgpt/gpt-6-luna|acknowledged_concession_rule|Defeat|model_surrender|12|
|3|chatgpt/gpt-6-luna|unverified|Unknown|context_budget|13|
|4|chatgpt/gpt-6-luna|acknowledged_concession_rule|Defeat|model_surrender|15|
|5|chatgpt/gpt-6-luna|unverified|Unknown|context_budget|13|
|6|chatgpt/gpt-6-luna|unverified|Unknown|context_budget|19|
|7|chatgpt/gpt-6-luna|acknowledged_concession_rule|Defeat|obvious_disadvantage_guard|24|
|8|chatgpt/gpt-6-luna|engine_player_result|Defeat|engine_end|24|
|9|chatgpt/gpt-6-luna|acknowledged_concession_rule|Defeat|model_surrender|19|
|10|chatgpt/gpt-6-luna|acknowledged_concession_rule|Defeat|model_surrender|20|
|11|chatgpt/gpt-6-luna|unverified|Unknown|context_budget|20|
|12|chatgpt/gpt-6-luna|engine_player_result|Defeat|engine_end|22|
|13|chatgpt/gpt-6-luna|acknowledged_concession_rule|Defeat|model_surrender|19|
|14|chatgpt/gpt-6-luna|acknowledged_concession_rule|Defeat|model_surrender|18|
|15|chatgpt/gpt-6-luna|engine_player_result|Defeat|engine_end|24|
|16|chatgpt/gpt-6-luna|acknowledged_concession_rule|Defeat|model_surrender|15|
|17|chatgpt/gpt-6-luna|unverified|Unknown|context_budget|21|
|18|chatgpt/gpt-6-luna|engine_player_result|Defeat|engine_end|23|
|19|chatgpt/gpt-6-luna|engine_player_result|Defeat|engine_end|23|
|20|chatgpt/gpt-6-luna|acknowledged_concession_rule|Defeat|model_surrender|24|
|21|chatgpt/gpt-6-luna|unverified|Unknown|model_unavailable|2|
|22|chatgpt/gpt-6-luna|engine_player_result|Defeat|engine_end|24|

Unknown为中断或预算停止，不能称作真实败局；确认投降与引擎自然结束分开记录。
原始单局实验文档保存在30min-single-trial-report.md与30min-single-trial-summary.json。
全部明细、模型请求、复盘与回放路径见campaign.json、summary.json及每局match.json。
